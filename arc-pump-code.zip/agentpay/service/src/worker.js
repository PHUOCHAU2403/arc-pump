// Agent-pay demo service — the "sell side" of the pay-per-call rail, plus a
// live ledger + dashboard.
//
//   GET /premium                  -> 402 + { invoice: { id, amount, router, service } }
//   (agent pays router.pay(id, service) on Arc)
//   GET /premium?invoice=<id>     -> 200 + data (verified on-chain, single-use);
//                                    the paid call is recorded to the ledger
//   GET /ledger                   -> JSON { purchases[], stats }
//   GET /                         -> HTML dashboard of agent purchases

const ROUTER = "0x42bCE0940b286b29A7bE50c3C7c89302A48E28ff";
const SERVICE = "0xfC6153A6d0Cc40E17d9B48fE2fb1AACd9C63114e"; // this service's payee (USDC lands here)
const RPC = "https://rpc.testnet.arc.network";
const ARCSCAN = "https://testnet.arcscan.app";
const PRICE_WEI = "10000000000000000"; // 0.01 USDC (native, 18 dec)
const PRICE_USDC = "0.01";
const VERIFY_SELECTOR = "0x3ab5b633"; // verify(bytes32,address,uint256)

const CORS = {
  "access-control-allow-origin": "*",
  "access-control-allow-methods": "GET,POST,OPTIONS",
  "access-control-allow-headers": "content-type,x-payment,x-agent,x-agent-name",
};
const cors = (r) => { for (const [k, v] of Object.entries(CORS)) r.headers.set(k, v); return r; };
const json = (o, status = 200) =>
  new Response(JSON.stringify(o, null, 2), { status, headers: { "content-type": "application/json", ...CORS } });

export default {
  async fetch(req, env) {
    try {
      const url = new URL(req.url);
      if (req.method === "OPTIONS") return cors(new Response(null, { status: 204 }));
      if (url.pathname === "/premium") return await premium(req, env, url);
      if (url.pathname === "/ledger") return json(await loadLedger(env));
      if (url.pathname === "/demo-pay" && req.method === "POST") return await demoPay(req, env);
      if (url.pathname === "/demo-status") return await demoStatus(req, env, url);
      if (url.pathname === "/hit") return await hit(req, env);
      if (url.pathname === "/analytics") return await analytics(req, env, url);
      return await dashboard(env);
    } catch (e) {
      return json({ error: "worker error: " + String((e && e.message) || e).slice(0, 220) }, 500);
    }
  },
};

async function premium(req, env, url) {
  const provided = url.searchParams.get("invoice") || req.headers.get("x-payment");

  if (!provided) {
    const id = "0x" + [...crypto.getRandomValues(new Uint8Array(32))].map((b) => b.toString(16).padStart(2, "0")).join("");
    await env.INVOICES.put(id, JSON.stringify({ resource: "/premium", price: PRICE_WEI, served: false, ts: Date.now() }), { expirationTtl: 900 });
    return json({
      error: "payment required",
      invoice: { id, amount: PRICE_WEI, amountUSDC: PRICE_USDC, router: ROUTER, service: SERVICE, resource: "/premium", chain: "arc-testnet", expiresInSec: 900 },
      how: `Call ${ROUTER}.pay(invoiceId, service) with ${PRICE_USDC} USDC, then retry GET /premium?invoice=${id}`,
    }, 402);
  }

  const inv = await env.INVOICES.get(provided, "json");
  if (!inv) return json({ error: "unknown or expired invoice" }, 400);
  if (inv.served) return json({ error: "invoice already used", invoice: provided }, 409);

  const ok = await verifyOnChain(provided, SERVICE, inv.price);
  if (!ok) return json({ error: "not paid yet", invoice: { id: provided, amount: inv.price, amountUSDC: PRICE_USDC, router: ROUTER, service: SERVICE } }, 402);

  inv.served = true;
  await env.INVOICES.put(provided, JSON.stringify(inv), { expirationTtl: 900 });

  // Record the verified purchase to the ledger.
  await recordPurchase(env, {
    invoice: provided,
    amountUSDC: PRICE_USDC,
    resource: "/premium",
    agent: (req.headers.get("x-agent") || "").slice(0, 44),
    agentName: (req.headers.get("x-agent-name") || "").slice(0, 40),
    ts: Date.now(),
  });

  return json({
    resource: "/premium",
    data: { insight: "On Arc, USDC is the native token — settlement is final in ~1s, which is exactly what per-call agent payments need.", generatedAt: new Date().toISOString() },
    payment: { invoice: provided, amountUSDC: PRICE_USDC, settledInUSDC: true, chain: "arc-testnet" },
  });
}

async function verifyOnChain(invoiceId, service, priceWei) {
  const pad = (h) => h.replace(/^0x/, "").toLowerCase().padStart(64, "0");
  const data = VERIFY_SELECTOR + invoiceId.slice(2) + pad(service) + pad(BigInt(priceWei).toString(16));
  try {
    const r = await fetch(RPC, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ jsonrpc: "2.0", id: 1, method: "eth_call", params: [{ to: ROUTER, data }, "latest"] }) });
    const res = (await r.json()).result;
    return res ? BigInt(res) === 1n : false;
  } catch {
    return false;
  }
}

async function recordPurchase(env, rec) {
  const key = `purchase:${(Number.MAX_SAFE_INTEGER - rec.ts).toString().padStart(16, "0")}:${rec.invoice.slice(2, 10)}`;
  await env.INVOICES.put(key, JSON.stringify(rec), { expirationTtl: 60 * 60 * 24 * 30 });
  const sraw = await env.INVOICES.get("ledger-stats");
  const s = sraw ? JSON.parse(sraw) : { count: 0, totalUSDC: 0, agents: [] };
  s.count++;
  s.totalUSDC = +(s.totalUSDC + Number(rec.amountUSDC)).toFixed(6);
  if (rec.agent && !s.agents.includes(rec.agent)) s.agents.push(rec.agent);
  await env.INVOICES.put("ledger-stats", JSON.stringify(s));
}

async function loadLedger(env) {
  const list = await env.INVOICES.list({ prefix: "purchase:", limit: 50 });
  const purchases = (await Promise.all(list.keys.map((k) => env.INVOICES.get(k.name, "json")))).filter(Boolean);
  const sraw = await env.INVOICES.get("ledger-stats");
  const stats = sraw ? JSON.parse(sraw) : { count: 0, totalUSDC: 0, agents: [] };
  return { purchases, stats, router: ROUTER, service: SERVICE, price: PRICE_USDC };
}

// ---------- sponsored demo payment (real, on-chain, rate-limited) ----------
// Lets a visitor trigger a REAL agent payment on Arc from the landing page.
// The agent's Circle wallet pays the invoice; spam is bounded by a per-IP
// cooldown + a global daily cap. Secrets: CIRCLE_API_KEY, CIRCLE_ENTITY_SECRET,
// CIRCLE_WALLET_ID (wrangler secret put).
const CIRCLE_API = "https://api.circle.com/v1/w3s";
const DEMO_DAILY_CAP = 300;

async function demoPay(req, env) {
  let b; try { b = await req.json(); } catch { return json({ error: "bad json" }, 400); }
  const invoice = String(b.invoice || "");
  if (!/^0x[0-9a-fA-F]{64}$/.test(invoice)) return json({ error: "a valid invoice is required" }, 400);
  if (!env.CIRCLE_API_KEY) return json({ error: "sponsor payments not configured" }, 503);

  const ip = req.headers.get("cf-connecting-ip") || "anon";
  const now = Date.now();
  const last = Number((await env.INVOICES.get(`dip:${ip}`)) || "0");
  if (now - last < 15000) return json({ error: "just a moment — one demo payment every ~15s" }, 429);
  const day = new Date().toISOString().slice(0, 10);
  const gc = Number((await env.INVOICES.get(`dcount:${day}`)) || "0");
  if (gc >= DEMO_DAILY_CAP) return json({ error: "daily demo limit reached — grab the SDK to keep going" }, 429);
  await env.INVOICES.put(`dip:${ip}`, String(now), { expirationTtl: 60 });

  let id;
  try { id = await circlePay(env, invoice); }
  catch (e) { return json({ error: "payment failed: " + String(e.message || e).slice(0, 160) }, 502); }
  await env.INVOICES.put(`dcount:${day}`, String(gc + 1), { expirationTtl: 60 * 60 * 26 });
  return json({ ok: true, id, invoice });
}

async function demoStatus(req, env, url) {
  const id = url.searchParams.get("id");
  if (!id) return json({ error: "id required" }, 400);
  try {
    const t = await circleGetTx(env, id);
    return json({ state: t.state, txHash: t.txHash || null });
  } catch (e) {
    return json({ error: String(e.message || e).slice(0, 160) }, 502);
  }
}

async function circlePay(env, invoice) {
  const body = {
    idempotencyKey: crypto.randomUUID(),
    entitySecretCiphertext: await entityCiphertext(env),
    walletId: env.CIRCLE_WALLET_ID,
    contractAddress: ROUTER,
    abiFunctionSignature: "pay(bytes32,address)",
    abiParameters: [invoice, SERVICE],
    amount: PRICE_USDC,
    feeLevel: "MEDIUM",
  };
  const r = await fetch(`${CIRCLE_API}/developer/transactions/contractExecution`, {
    method: "POST",
    headers: { authorization: `Bearer ${env.CIRCLE_API_KEY}`, "content-type": "application/json" },
    body: JSON.stringify(body),
  });
  const j = await r.json();
  if (!j?.data?.id) throw new Error(j?.message || JSON.stringify(j).slice(0, 160));
  return j.data.id;
}

async function circleGetTx(env, id) {
  const r = await fetch(`${CIRCLE_API}/transactions/${id}`, { headers: { authorization: `Bearer ${env.CIRCLE_API_KEY}` } });
  const j = await r.json();
  const t = j?.data?.transaction || {};
  return { state: t.state || "UNKNOWN", txHash: t.txHash };
}

// Encrypt the 32-byte entity secret with Circle's RSA public key (per request).
async function entityCiphertext(env) {
  const r = await fetch(`${CIRCLE_API}/config/entity/publicKey`, { headers: { authorization: `Bearer ${env.CIRCLE_API_KEY}` } });
  const pem = (await r.json())?.data?.publicKey;
  if (!pem) throw new Error("could not fetch entity public key");
  const der = pemToDer(pem);
  const key = await crypto.subtle.importKey("spki", der, { name: "RSA-OAEP", hash: "SHA-256" }, false, ["encrypt"]);
  const ct = await crypto.subtle.encrypt({ name: "RSA-OAEP" }, key, hexToBytes(env.CIRCLE_ENTITY_SECRET));
  return btoa(String.fromCharCode(...new Uint8Array(ct)));
}
function pemToDer(pem) {
  const b64 = pem.replace(/-----[^-]+-----/g, "").replace(/\s+/g, "");
  const bin = atob(b64);
  const buf = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) buf[i] = bin.charCodeAt(i);
  return buf.buffer;
}
function hexToBytes(h) {
  h = h.replace(/^0x/, "");
  const a = new Uint8Array(h.length / 2);
  for (let i = 0; i < a.length; i++) a[i] = parseInt(h.substr(i * 2, 2), 16);
  return a;
}

// ---------- analytics ----------
// Lightweight, privacy-respecting: daily page views + unique visitors (by a
// short hash of IP, never the raw IP). Demo runs come from the dcount counter.
const todayUTC = () => new Date().toISOString().slice(0, 10);

async function hit(req, env) {
  const day = todayUTC();
  const views = Number((await env.INVOICES.get(`views:${day}`)) || "0") + 1;
  await env.INVOICES.put(`views:${day}`, String(views), { expirationTtl: 60 * 60 * 24 * 40 });
  // unique visitor: hash the IP so we never store it raw
  const ip = req.headers.get("cf-connecting-ip") || "anon";
  const h = await sha8(ip + ":" + day);
  if (!(await env.INVOICES.get(`uv:${day}:${h}`))) {
    await env.INVOICES.put(`uv:${day}:${h}`, "1", { expirationTtl: 60 * 60 * 48 });
    const u = Number((await env.INVOICES.get(`uniq:${day}`)) || "0") + 1;
    await env.INVOICES.put(`uniq:${day}`, String(u), { expirationTtl: 60 * 60 * 24 * 40 });
  }
  return json({ ok: true });
}

async function analytics(req, env, url) {
  if (!env.ANALYTICS_KEY || url.searchParams.get("key") !== env.ANALYTICS_KEY)
    return json({ error: "unauthorized" }, 403);
  const days = [];
  let tViews = 0, tUniq = 0, tRuns = 0;
  for (let i = 0; i < 7; i++) {
    const d = new Date(Date.now() - i * 86400000).toISOString().slice(0, 10);
    const views = Number((await env.INVOICES.get(`views:${d}`)) || "0");
    const uniq = Number((await env.INVOICES.get(`uniq:${d}`)) || "0");
    const demoRuns = Number((await env.INVOICES.get(`dcount:${d}`)) || "0");
    days.push({ day: d, views, uniqueVisitors: uniq, demoRuns });
    tViews += views; tUniq += uniq; tRuns += demoRuns;
  }
  const ledger = await loadLedger(env);
  return json({ last7days: days, totals: { views: tViews, uniqueVisitors: tUniq, demoRuns: tRuns, paidCalls: ledger.stats.count || 0, usdcSettled: ledger.stats.totalUSDC || 0 } });
}

async function sha8(s) {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(s));
  return [...new Uint8Array(buf)].slice(0, 4).map((b) => b.toString(16).padStart(2, "0")).join("");
}

// ---------- dashboard ----------
function esc(s) { return String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c])); }
function ago(ts) { const m = Math.floor((Date.now() - ts) / 60000), h = Math.floor(m / 60); if (m < 1) return "just now"; if (m < 60) return m + "m ago"; if (h < 24) return h + "h ago"; return Math.floor(h / 24) + "d ago"; }
function short(a) { return a ? a.slice(0, 8) + "…" + a.slice(-4) : "—"; }

async function dashboard(env) {
  const { purchases, stats } = await loadLedger(env);
  const rows = purchases.length
    ? purchases.map((p) => `
      <div class="row">
        <div class="who">${p.agentName ? esc(p.agentName) : "Agent"}${p.agent ? `<a href="${ARCSCAN}/address/${esc(p.agent)}" target="_blank">${esc(short(p.agent))}</a>` : ""}</div>
        <div class="what">paid for <b>${esc(p.resource)}</b></div>
        <div class="amt">${esc(p.amountUSDC)} USDC</div>
        <div class="time">${ago(p.ts)}</div>
      </div>`).join("")
    : `<div class="empty">No purchases yet — point an agent at <code>/premium</code>.</div>`;

  const html = `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Agent-pay — pay-per-call ledger on Arc</title>
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Newsreader:ital,wght@0,500;1,400&family=Inter+Tight:wght@400;500&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
<style>
:root{--paper:#FAFAF7;--ink:#0a0a0a;--ink2:#2a2a2a;--mute:#6b6b6b;--faint:#9a9a92;--line:#e5e5dd;--accent:#c2410c;--good:#166534}
*{box-sizing:border-box}body{margin:0;background:var(--paper);color:var(--ink);font-family:"Inter Tight",system-ui,sans-serif;line-height:1.5}
.wrap{max-width:720px;margin:0 auto;padding:56px 24px 96px}
.kicker{font-family:"JetBrains Mono",monospace;font-size:11px;letter-spacing:.18em;text-transform:uppercase;color:var(--mute)}
.dot{display:inline-block;width:6px;height:6px;border-radius:50%;background:var(--good);margin-right:7px;vertical-align:middle}
h1{font-family:"Newsreader",Georgia,serif;font-weight:500;font-size:clamp(2rem,5vw,3rem);letter-spacing:-.03em;line-height:1.03;margin:.3em 0 .3em}
.lede{color:var(--ink2);font-size:1.02rem;max-width:56ch}
.stats{display:grid;grid-template-columns:repeat(3,1fr);gap:1px;background:var(--line);border:1px solid var(--line);margin:36px 0 10px}
.stat{background:var(--paper);padding:16px 14px}.stat .n{font-family:"JetBrains Mono",monospace;font-size:1.5rem;font-weight:500}.stat .l{font-size:10.5px;letter-spacing:.12em;text-transform:uppercase;color:var(--mute);margin-top:4px}
.tape{font-family:"JetBrains Mono",monospace;font-size:11px;letter-spacing:.18em;text-transform:uppercase;color:var(--mute);margin:40px 0 6px}
h2{font-family:"Newsreader",serif;font-weight:500;font-size:1.5rem;margin:0 0 16px}
.row{display:grid;grid-template-columns:1fr auto auto;gap:14px;align-items:baseline;padding:14px 0;border-top:1px solid var(--line)}
.who{font-weight:500}.who a{font-family:"JetBrains Mono",monospace;font-size:12px;color:var(--mute);margin-left:8px;text-decoration:none}
.what{color:var(--ink2)}.what b{font-family:"JetBrains Mono",monospace;font-weight:500;font-size:.92em}
.amt{font-family:"JetBrains Mono",monospace;color:var(--good);font-weight:500;white-space:nowrap}
.time{font-family:"JetBrains Mono",monospace;font-size:12px;color:var(--faint);white-space:nowrap}
.grid3 .what{grid-column:1/-1}
.empty{padding:36px 0;color:var(--faint);border-top:1px solid var(--line)}
.foot{margin-top:56px;font-size:12px;color:var(--faint);border-top:1px solid var(--line);padding-top:18px;line-height:1.7}
.foot a{color:var(--accent);text-decoration:none}
code{font-family:"JetBrains Mono",monospace;font-size:.9em}
@media(max-width:520px){.row{grid-template-columns:1fr auto}.time{display:none}}
</style></head><body><div class="wrap">
<div class="kicker"><span class="dot"></span>Pay-per-call · settled in USDC on Arc</div>
<h1>Agents paying for what they use.</h1>
<p class="lede">A live ledger of autonomous AI agents paying per request in USDC on Arc — each call metered, priced, and settled on-chain through the PaymentRouter. No subscriptions, no humans.</p>
<div class="stats">
  <div class="stat"><div class="n">${stats.count || 0}</div><div class="l">Paid calls</div></div>
  <div class="stat"><div class="n">${(stats.totalUSDC || 0).toFixed(2)}</div><div class="l">USDC settled</div></div>
  <div class="stat"><div class="n">${(stats.agents || []).length}</div><div class="l">Agents</div></div>
</div>
<div class="tape">Ledger</div>
<h2>Who paid for what</h2>
${rows}
<div class="foot">
  PaymentRouter <a href="${ARCSCAN}/address/${ROUTER}" target="_blank">${short(ROUTER)}</a> · price ${PRICE_USDC} USDC/call · Arc testnet<br>
  An agent pays per request in native USDC; the service verifies the payment on-chain before serving. Try it: <code>GET /premium</code>.
</div>
</div>
<script>setTimeout(()=>location.reload(),30000)</script>
</body></html>`;
  return new Response(html, { headers: { "content-type": "text/html; charset=utf-8" } });
}
